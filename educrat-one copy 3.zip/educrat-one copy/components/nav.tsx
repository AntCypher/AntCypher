import Link from 'next/link';
import React from 'react';

function MenuItem({ item }) {
  return (
    <li>
      <Link href={item.uri}>{item.label}</Link>
      {item.childItems && (
        <ul>
          {item.childItems.edges.map((childItem) => (
            <MenuItem key={childItem.node.id} item={childItem.node} />
          ))}
        </ul>
      )}
    </li>
  );
}

export default function Nav({ headerMenus }) {

  return (
    <nav>
      <ul>
        {headerMenus?.headerMenus?.edges?.map((menuItem) => (
          <MenuItem key={menuItem.node.id} item={menuItem.node} />
        ))}
      </ul>
    </nav>
  );
}