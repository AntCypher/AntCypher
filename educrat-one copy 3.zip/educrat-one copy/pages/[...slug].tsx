import { useRouter } from 'next/router';
import { GetServerSideProps } from 'next';
import Layout from '../components/layout';
import { getPreviewPageByUri, getPrimaryMenu } from '../lib/api';
import Header from '../components/header';
import PostTitle from '../components/post-title';

export default function DynamicPage({ preview, PageData, headerMenus }) {
  const router = useRouter(); 
  const { title, content } = PageData;

  return (
    <Layout preview={preview}>
      {router.isFallback ? (
          <PostTitle>Loading…</PostTitle>
        ) : (
          <>
      <Header headerMenus={headerMenus} />
      <h1>{title}</h1>
      <div dangerouslySetInnerHTML={{ __html: content }} />
      <p>Current slug: {router.query.slug}</p> {/* Display the current slug for demonstration */}
      </>
        )}
    </Layout>
  );
}

export const getServerSideProps: GetServerSideProps = async ({ preview = false, params }) => {
  const slug = params?.slug as string[] | undefined; 
  const uri = slug ? `/${slug.join('/')}` : '';

  const PageData = await getPreviewPageByUri({ uri });
  const headerMenus = await getPrimaryMenu();


  return {
    props: { preview, PageData, headerMenus },
  };
}