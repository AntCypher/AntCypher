import Head from 'next/head';
import Layout from '../components/layout';
import { GetServerSideProps } from 'next';
import { getPreviewPageByUri, getPrimaryMenu } from '../lib/api';
import Header from '../components/header';

export default function Index({ PageData, preview, headerMenus }) {
  const { title, content } = PageData;

  return (
    <Layout preview={preview}>
      <Head>
        <title>{title}</title>
      </Head>
      <>
      <Header headerMenus={headerMenus}/>
      
        <h1>{title}</h1>
        <div dangerouslySetInnerHTML={{ __html: content }} />
      </>
    </Layout>
  );
}

export const getServerSideProps: GetServerSideProps = async ({ preview = false }) => {
  const PageData = await getPreviewPageByUri({ uri: 'home' });
  const headerMenus = await getPrimaryMenu()

  return {
    props: { PageData, preview, headerMenus },
  };
}